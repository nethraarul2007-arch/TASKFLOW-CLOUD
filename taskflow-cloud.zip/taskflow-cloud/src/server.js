'use strict';

const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { URL } = require('node:url');
const { TaskQueue } = require('./queue');
const { WorkerPool } = require('./worker-pool');

const PORT = Number(process.env.PORT) || 3000;
const PUBLIC_DIR = path.join(__dirname, '..', 'public');
const queue = new TaskQueue({
  maxAttempts: Number(process.env.MAX_ATTEMPTS) || 3,
  retryBaseMs: Number(process.env.RETRY_BASE_MS) || 1200
});
const pool = new WorkerPool(queue, { size: Number(process.env.WORKER_COUNT) || 3 });
pool.start();

function sendJson(res, status, data) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type'
  });
  res.end(JSON.stringify(data));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => {
      body += chunk;
      if (body.length > 1_000_000) {
        reject(new Error('Request body too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!body) return resolve({});
      try { resolve(JSON.parse(body)); } catch { reject(new Error('Request body must be valid JSON.')); }
    });
    req.on('error', reject);
  });
}

function serveStatic(req, res, pathname) {
  const requested = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.resolve(PUBLIC_DIR, '.' + decodeURIComponent(requested));
  if (!filePath.startsWith(PUBLIC_DIR + path.sep)) return sendJson(res, 403, { error: 'Forbidden path.' });
  fs.readFile(filePath, (err, content) => {
    if (err) return sendJson(res, 404, { error: 'File not found.' });
    const ext = path.extname(filePath).toLowerCase();
    const types = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.svg': 'image/svg+xml' };
    res.writeHead(200, { 'Content-Type': types[ext] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(content);
  });
}

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') return sendJson(res, 204, {});
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  try {
    if (pathname.startsWith('/api/')) {
      if (req.method === 'GET' && pathname === '/api/health') {
        return sendJson(res, 200, { ok: true, uptime: process.uptime(), node: process.version });
      }
      if (req.method === 'GET' && pathname === '/api/overview') {
        return sendJson(res, 200, {
          stats: queue.getStats(),
          workers: [...queue.workers.values()].map(w => ({ ...w })),
          tasks: queue.listTasks({ limit: 200 }),
          deadLetters: queue.deadLetterQueue,
          failures: queue.failureLogs.slice(0, 100),
          events: queue.events.slice(0, 50)
        });
      }
      if (req.method === 'GET' && pathname === '/api/tasks') {
        return sendJson(res, 200, { tasks: queue.listTasks({ status: url.searchParams.get('status') || 'all', limit: url.searchParams.get('limit') || 100 }) });
      }
      if (req.method === 'POST' && pathname === '/api/tasks') {
        const body = await readBody(req);
        const task = queue.addTask(body);
        return sendJson(res, 201, { task });
      }
      if (req.method === 'POST' && pathname === '/api/demo') {
        const samples = [
          { title: 'Generate monthly report', priority: 'high', durationMs: 2300, payload: { format: 'pdf' } },
          { title: 'Resize uploaded images', priority: 'normal', durationMs: 1800, payload: { count: 12 } },
          { title: 'Send billing reminders', priority: 'critical', durationMs: 1400, payload: { batch: 'october' } },
          { title: 'Sync analytics data', priority: 'low', durationMs: 2600, payload: { source: 'events' } },
          { title: 'Retry demonstration job', priority: 'high', durationMs: 900, failFirst: true }
        ];
        return sendJson(res, 201, { tasks: samples.map(task => queue.addTask(task)) });
      }
      if (req.method === 'POST' && pathname === '/api/queue/pause') {
        queue.paused = true;
        return sendJson(res, 200, { paused: true });
      }
      if (req.method === 'POST' && pathname === '/api/queue/resume') {
        queue.paused = false;
        return sendJson(res, 200, { paused: false });
      }
      const retryMatch = pathname.match(/^\/api\/dead-letter\/([^/]+)\/retry$/);
      if (req.method === 'POST' && retryMatch) {
        const ok = queue.retryDeadLetter(decodeURIComponent(retryMatch[1]));
        return ok ? sendJson(res, 200, { ok: true }) : sendJson(res, 404, { error: 'Dead-letter task not found.' });
      }
      if (req.method === 'DELETE' && pathname === '/api/tasks') {
        // Only clear completed/failed history; active and queued jobs remain safe.
        let removed = 0;
        for (const [id, task] of queue.tasks) {
          if (task.status === 'completed' || task.status === 'failed') {
            queue.tasks.delete(id); removed++;
          }
        }
        queue.deadLetterQueue = [];
        queue.failureLogs = [];
        queue.events.unshift({ id: `clear-${Date.now()}`, type: 'history.cleared', timestamp: new Date().toISOString(), removed });
        return sendJson(res, 200, { removed });
      }
      return sendJson(res, 404, { error: 'API route not found.' });
    }
    if (req.method !== 'GET' && req.method !== 'HEAD') return sendJson(res, 405, { error: 'Method not allowed.' });
    return serveStatic(req, res, pathname);
  } catch (error) {
    const status = /required|must be|Priority|Duration/.test(error.message) ? 400 : 500;
    return sendJson(res, status, { error: error.message || 'Internal server error.' });
  }
});

server.listen(PORT, () => {
  console.log(`TaskFlow Cloud running at http://localhost:${PORT}`);
  console.log(`Workers: ${pool.size} | Max attempts: ${queue.maxAttempts}`);
});

function shutdown() {
  pool.stop();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 3000).unref();
}
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);

module.exports = { server, queue, pool };
