'use strict';

const crypto = require('node:crypto');

const PRIORITY = Object.freeze({ critical: 4, high: 3, normal: 2, low: 1 });
const TERMINAL = new Set(['completed', 'failed']);

class TaskQueue {
  constructor({ maxAttempts = 3, retryBaseMs = 1200, historyLimit = 500 } = {}) {
    this.maxAttempts = maxAttempts;
    this.retryBaseMs = retryBaseMs;
    this.historyLimit = historyLimit;
    this.tasks = new Map();
    this.waiting = [];
    this.deadLetterQueue = [];
    this.failureLogs = [];
    this.events = [];
    this.workers = new Map();
    this.paused = false;
    this.sequence = 0;
  }

  addTask({ title, payload = {}, priority = 'normal', durationMs = 1800, failFirst = false } = {}) {
    if (!title || !String(title).trim()) throw new Error('Task title is required.');
    if (!(priority in PRIORITY)) throw new Error('Priority must be critical, high, normal, or low.');
    const duration = Number(durationMs);
    if (!Number.isFinite(duration) || duration < 100 || duration > 60000) {
      throw new Error('Duration must be between 100 and 60000 milliseconds.');
    }
    const now = new Date().toISOString();
    const task = {
      id: crypto.randomUUID(),
      sequence: ++this.sequence,
      title: String(title).trim().slice(0, 120),
      payload: payload && typeof payload === 'object' ? payload : { value: payload },
      priority,
      priorityValue: PRIORITY[priority],
      durationMs: duration,
      failFirst: Boolean(failFirst),
      status: 'queued',
      attempts: 0,
      maxAttempts: this.maxAttempts,
      createdAt: now,
      updatedAt: now,
      startedAt: null,
      completedAt: null,
      workerId: null,
      error: null,
      result: null,
      retryAt: null
    };
    this.tasks.set(task.id, task);
    this.waiting.push(task.id);
    this._event('task.created', { taskId: task.id, title: task.title, priority });
    this._trim();
    return this.publicTask(task);
  }

  registerWorker(worker) {
    this.workers.set(worker.id, { ...worker, status: 'idle', currentTaskId: null, completed: 0, failed: 0 });
    this._event('worker.registered', { workerId: worker.id, name: worker.name });
  }

  unregisterWorker(workerId) {
    this.workers.delete(workerId);
    this._event('worker.unregistered', { workerId });
  }

  claimNext(workerId) {
    if (this.paused) return null;
    const worker = this.workers.get(workerId);
    if (!worker || worker.status === 'busy') return null;
    this._promoteRetries();
    const candidates = this.waiting
      .map(id => this.tasks.get(id))
      .filter(t => t && t.status === 'queued' && !t.retryAt);
    candidates.sort((a, b) => b.priorityValue - a.priorityValue || a.sequence - b.sequence);
    const task = candidates[0];
    if (!task) return null;
    this.waiting = this.waiting.filter(id => id !== task.id);
    task.status = 'running';
    task.attempts += 1;
    task.workerId = workerId;
    task.startedAt = new Date().toISOString();
    task.updatedAt = task.startedAt;
    task.retryAt = null;
    task.error = null;
    worker.status = 'busy';
    worker.currentTaskId = task.id;
    this._event('task.started', { taskId: task.id, workerId, attempt: task.attempts });
    return { ...this.publicTask(task), failFirst: task.failFirst };
  }

  completeTask(taskId, workerId, result) {
    const task = this.tasks.get(taskId);
    const worker = this.workers.get(workerId);
    if (!task || task.status !== 'running' || task.workerId !== workerId) return false;
    task.status = 'completed';
    task.result = result ?? { message: 'Task completed successfully.' };
    task.completedAt = new Date().toISOString();
    task.updatedAt = task.completedAt;
    worker.status = 'idle';
    worker.currentTaskId = null;
    worker.completed += 1;
    this._event('task.completed', { taskId, workerId, attempt: task.attempts });
    return true;
  }

  failTask(taskId, workerId, error) {
    const task = this.tasks.get(taskId);
    const worker = this.workers.get(workerId);
    if (!task || task.status !== 'running' || task.workerId !== workerId) return false;
    const message = error instanceof Error ? error.message : String(error || 'Unknown task failure');
    task.error = message;
    task.updatedAt = new Date().toISOString();
    worker.status = 'idle';
    worker.currentTaskId = null;
    worker.failed += 1;
    this.failureLogs.unshift({
      id: crypto.randomUUID(), taskId, taskTitle: task.title, workerId,
      attempt: task.attempts, message, timestamp: task.updatedAt
    });
    if (this.failureLogs.length > this.historyLimit) this.failureLogs.length = this.historyLimit;

    if (task.attempts < task.maxAttempts) {
      task.status = 'queued';
      const delay = this.retryBaseMs * Math.pow(2, task.attempts - 1);
      task.retryAt = Date.now() + delay;
      this.waiting.push(task.id);
      this._event('task.retry_scheduled', { taskId, attempt: task.attempts, retryAt: task.retryAt, message });
    } else {
      task.status = 'failed';
      task.completedAt = task.updatedAt;
      this.deadLetterQueue.unshift({
        taskId: task.id, title: task.title, priority: task.priority,
        attempts: task.attempts, lastError: message, failedAt: task.updatedAt
      });
      this._event('task.dead_lettered', { taskId, attempts: task.attempts, message });
    }
    this._trim();
    return true;
  }

  retryDeadLetter(taskId) {
    const index = this.deadLetterQueue.findIndex(item => item.taskId === taskId);
    const task = this.tasks.get(taskId);
    if (index < 0 || !task) return false;
    this.deadLetterQueue.splice(index, 1);
    task.status = 'queued';
    task.attempts = 0;
    task.error = null;
    task.result = null;
    task.completedAt = null;
    task.retryAt = null;
    task.workerId = null;
    task.updatedAt = new Date().toISOString();
    this.waiting.push(taskId);
    this._event('task.dead_letter_requeued', { taskId });
    return true;
  }

  getStats() {
    const counts = { queued: 0, running: 0, completed: 0, failed: 0 };
    for (const task of this.tasks.values()) if (counts[task.status] !== undefined) counts[task.status]++;
    return {
      ...counts,
      total: this.tasks.size,
      workers: this.workers.size,
      activeWorkers: [...this.workers.values()].filter(w => w.status === 'busy').length,
      deadLetterCount: this.deadLetterQueue.length,
      paused: this.paused
    };
  }

  listTasks({ status, limit = 100 } = {}) {
    let tasks = [...this.tasks.values()];
    if (status && status !== 'all') tasks = tasks.filter(t => t.status === status);
    return tasks.sort((a, b) => b.sequence - a.sequence).slice(0, Math.max(1, Math.min(Number(limit) || 100, 500))).map(t => this.publicTask(t));
  }

  publicTask(task) {
    const { priorityValue, failFirst, sequence, ...safe } = task;
    return { ...safe };
  }

  _promoteRetries() {
    const now = Date.now();
    for (const task of this.tasks.values()) {
      if (task.status === 'queued' && task.retryAt && task.retryAt <= now) task.retryAt = null;
    }
  }

  _event(type, data) {
    this.events.unshift({ id: crypto.randomUUID(), type, timestamp: new Date().toISOString(), ...data });
    if (this.events.length > this.historyLimit) this.events.length = this.historyLimit;
  }

  _trim() {
    // Keep task records bounded without removing active or queued work.
    if (this.tasks.size <= this.historyLimit) return;
    const removable = [...this.tasks.values()]
      .filter(t => TERMINAL.has(t.status))
      .sort((a, b) => a.sequence - b.sequence);
    while (this.tasks.size > this.historyLimit && removable.length) this.tasks.delete(removable.shift().id);
  }
}

module.exports = { TaskQueue, PRIORITY };
