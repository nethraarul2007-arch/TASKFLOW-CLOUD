'use strict';

class WorkerPool {
  constructor(queue, { size = 3, pollIntervalMs = 150, retryBaseMs = 1200 } = {}) {
    this.queue = queue;
    this.size = Math.max(1, Math.min(8, Number(size) || 3));
    this.pollIntervalMs = pollIntervalMs;
    this.retryBaseMs = retryBaseMs;
    this.running = false;
    this.timers = new Set();
    this.workerIds = [];
  }

  start() {
    if (this.running) return;
    this.running = true;
    for (let i = 1; i <= this.size; i++) {
      const worker = { id: `worker-${i}`, name: `Worker ${i}` };
      this.workerIds.push(worker.id);
      this.queue.registerWorker(worker);
      this._schedule(worker.id, 0);
    }
  }

  stop() {
    this.running = false;
    for (const timer of this.timers) clearTimeout(timer);
    this.timers.clear();
    for (const id of this.workerIds) this.queue.unregisterWorker(id);
    this.workerIds = [];
  }

  _schedule(workerId, delay = this.pollIntervalMs) {
    if (!this.running) return;
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      this._tick(workerId);
    }, delay);
    this.timers.add(timer);
  }

  _tick(workerId) {
    if (!this.running) return;
    const task = this.queue.claimNext(workerId);
    if (!task) {
      this._schedule(workerId);
      return;
    }

    const duration = Math.max(100, Math.min(task.durationMs, 60000));
    const timer = setTimeout(() => {
      this.timers.delete(timer);
      if (!this.running) return;
      // Demo switch: fail the first attempt only, then succeed on retry.
      if (task.failFirst && task.attempts === 1) {
        this.queue.failTask(task.id, workerId, new Error('Simulated failure (fail-first demo flag).'));
      } else if (task.payload && task.payload.forceFailure) {
        this.queue.failTask(task.id, workerId, new Error(String(task.payload.forceFailure)));
      } else {
        this.queue.completeTask(task.id, workerId, {
          message: `Processed "${task.title}"`,
          processedAt: new Date().toISOString(),
          workerId,
          attempt: task.attempts
        });
      }
      this._schedule(workerId, 0);
    }, duration);
    this.timers.add(timer);
  }
}

module.exports = { WorkerPool };
