# TaskFlow Cloud Architecture

## Architecture diagram

```mermaid
flowchart TD
    U[User / Browser] -->|HTML, CSS, JS| UI[Dashboard UI]
    UI -->|HTTP REST / JSON| API[Node.js HTTP Server]
    API --> Q[Task Queue and Scheduler]
    API --> R[Task / Worker / Log Read APIs]
    Q -->|Claim highest eligible priority| W1[Worker 1]
    Q -->|Claim highest eligible priority| W2[Worker 2]
    Q -->|Claim highest eligible priority| WN[Worker N]
    W1 -->|success / failure| Q
    W2 -->|success / failure| Q
    WN -->|success / failure| Q
    Q -->|attempts remain| RB[Retry Backoff]
    RB --> Q
    Q -->|retry limit reached| DLQ[Dead-letter Queue]
    Q --> LOG[Failure Logs and Events]
    R --> UI
```

## Main modules

- **`public/`** — frontend dashboard, styling, and browser-side API client.
- **`src/server.js`** — HTTP routing, JSON request parsing, static-file serving, and API responses.
- **`src/queue.js`** — in-memory task records, priority selection, state transitions, retry timing, failure logs, and DLQ.
- **`src/worker-pool.js`** — concurrent workers that poll the queue and simulate job execution.
- **`test/queue.test.js`** — deterministic unit tests for core queue behavior.

## Task lifecycle

```mermaid
stateDiagram-v2
    [*] --> Queued
    Queued --> Running: worker claims task
    Running --> Completed: successful execution
    Running --> Queued: failure and attempts remain
    Queued --> Running: retry delay elapsed
    Running --> Failed: retry limit exhausted
    Failed --> Queued: manual DLQ requeue
```

## Priority rules

| Priority | Weight |
|---|---:|
| Critical | 4 |
| High | 3 |
| Normal | 2 |
| Low | 1 |

The scheduler always chooses the highest-priority task eligible at the instant a worker claims a job. Tasks of the same priority are processed in creation order. A task already running is not preempted when a higher-priority task arrives.

## Concurrency and reliability

Each worker is a separate asynchronous worker loop in the same Node.js process. Timers simulate I/O-bound work, allowing several tasks to run concurrently without blocking the event loop. Retry delays use exponential backoff. Each failed attempt is logged, while tasks that exhaust their attempt budget are placed in the DLQ for inspection or manual requeue.

## Limitations and production hardening

This is a learning project, not a durable distributed queue. In-memory records are lost on restart, worker execution is simulated, and multiple server processes do not share queue state. A production system should add durable persistence, distributed locking/leases, graceful in-flight task recovery, authentication and authorization, request rate limits, structured logging, metrics, and real job handlers.
