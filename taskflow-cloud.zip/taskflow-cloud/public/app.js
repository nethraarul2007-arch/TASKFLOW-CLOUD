'use strict';

const $ = selector => document.querySelector(selector);
const els = {
  total: $('#stat-total'), queued: $('#stat-queued'), running: $('#stat-running'),
  completed: $('#stat-completed'), failed: $('#stat-failed'), navQueued: $('#nav-queued'),
  taskRows: $('#task-rows'), taskCount: $('#task-count'), workerList: $('#worker-list'),
  workerCount: $('#worker-count'), busyCount: $('#busy-count'), idleCount: $('#idle-count'),
  failureList: $('#failure-list'), failureCount: $('#failure-count'), deadList: $('#dead-list'),
  dlqCount: $('#dlq-count'), failureRate: $('#failure-rate'), uptime: $('#uptime'),
  pauseBtn: $('#pause-btn'), modal: $('#task-modal'), form: $('#task-form'), toast: $('#toast')
};
let overview = null;
let toastTimer = null;

async function api(path, options = {}) {
  const response = await fetch(path, {
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body;
}
function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);
}
function shortId(id) { return id ? id.slice(0, 8) : '—'; }
function relativeTime(value) {
  if (!value) return '—';
  const seconds = Math.max(0, Math.floor((Date.now() - new Date(value).getTime()) / 1000));
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  return `${Math.floor(seconds / 3600)}h ago`;
}
function timeOf(value) {
  if (!value) return '—';
  return new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
}
function toast(message) {
  els.toast.textContent = message;
  els.toast.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => els.toast.classList.remove('show'), 2600);
}
function renderStats(stats) {
  els.total.textContent = stats.total;
  els.queued.textContent = stats.queued;
  els.running.textContent = stats.running;
  els.completed.textContent = stats.completed;
  els.failed.textContent = stats.deadLetterCount;
  els.navQueued.textContent = stats.queued;
  els.failureRate.textContent = `${stats.failed} failed`;
  els.pauseBtn.textContent = stats.paused ? '▶ Resume queue' : 'Ⅱ Pause queue';
  els.pauseBtn.dataset.paused = String(stats.paused);
}
function renderTasks(tasks) {
  const filter = $('#status-filter').value;
  const visible = filter === 'all' ? tasks : tasks.filter(task => task.status === filter);
  els.taskCount.textContent = `Showing ${visible.length} task${visible.length === 1 ? '' : 's'}`;
  if (!visible.length) {
    els.taskRows.innerHTML = '<tr><td colspan="6" class="empty">No tasks here yet. Add a task or load the demo.</td></tr>';
    return;
  }
  els.taskRows.innerHTML = visible.map(task => `
    <tr>
      <td><div class="task-title" title="${escapeHtml(task.title)}">${escapeHtml(task.title)}</div><div class="task-id">#${shortId(task.id)}</div></td>
      <td><span class="priority priority-${escapeHtml(task.priority)}">${escapeHtml(task.priority)}</span></td>
      <td><span class="status status-${escapeHtml(task.status)}">${escapeHtml(task.status)}</span></td>
      <td class="attempts">${task.attempts}/${task.maxAttempts}</td>
      <td class="worker-tag">${task.workerId ? escapeHtml(task.workerId.replace('worker-', 'W-')) : '—'}</td>
      <td>${relativeTime(task.createdAt)}</td>
    </tr>`).join('');
}
function renderWorkers(workers) {
  const busy = workers.filter(worker => worker.status === 'busy').length;
  els.workerCount.textContent = `${workers.length} workers`;
  els.busyCount.textContent = busy;
  els.idleCount.textContent = workers.length - busy;
  els.workerList.innerHTML = workers.map(worker => {
    const task = overview.tasks.find(item => item.id === worker.currentTaskId);
    const label = task ? task.title : 'Waiting for next task';
    return `<div class="worker-card">
      <div class="worker-icon">⌘</div>
      <div class="worker-info"><strong>${escapeHtml(worker.name)}</strong><small>${escapeHtml(label)}</small>${worker.status === 'busy' ? '<div class="worker-progress"><span style="width:70%"></span></div>' : ''}</div>
      <span class="worker-state state-${worker.status}">${worker.status}</span>
    </div>`;
  }).join('') || '<div class="empty">No workers registered.</div>';
}
function renderFailures(failures) {
  els.failureCount.textContent = `${failures.length} events`;
  els.failureList.innerHTML = failures.length ? failures.slice(0, 8).map(log => `
    <div class="log-item"><div class="log-icon">!</div><div class="log-content"><strong>${escapeHtml(log.taskTitle)} · attempt ${log.attempt}</strong><p>${escapeHtml(log.message)} · ${escapeHtml(log.workerId)}</p></div><span class="log-time">${timeOf(log.timestamp)}</span></div>`).join('') : '<div class="empty">No failures recorded. Create a task with “Simulate one failure” to test retries.</div>';
}
function renderDeadLetters(items) {
  els.dlqCount.textContent = `${items.length} jobs`;
  els.deadList.innerHTML = items.length ? items.slice(0, 8).map(item => `
    <div class="dead-item"><div class="log-icon">↳</div><div class="dead-content"><strong>${escapeHtml(item.title)}</strong><p>${escapeHtml(item.lastError)}</p><small>${item.attempts} attempts · ${timeOf(item.failedAt)}</small></div><button class="retry-btn" data-retry="${escapeHtml(item.taskId)}">Requeue</button></div>`).join('') : '<div class="empty">Dead-letter queue is empty. Exhausted jobs will appear here.</div>';
}
async function refresh() {
  try {
    overview = await api('/api/overview');
    renderStats(overview.stats);
    renderTasks(overview.tasks);
    renderWorkers(overview.workers);
    renderFailures(overview.failures);
    renderDeadLetters(overview.deadLetters);
    els.uptime.textContent = `API online · ${Math.floor(overview.stats.total ? performance.now() / 1000 : 0)}s session`;
  } catch (error) {
    els.uptime.textContent = 'API unavailable';
  }
}
function openModal() { els.modal.hidden = false; setTimeout(() => els.form.elements.title.focus(), 30); }
function closeModal() { els.modal.hidden = true; els.form.reset(); }

$('#new-task-btn').addEventListener('click', openModal);
$('#close-modal').addEventListener('click', closeModal);
$('#cancel-modal').addEventListener('click', closeModal);
els.modal.addEventListener('click', event => { if (event.target === els.modal) closeModal(); });
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeModal(); });
$('#status-filter').addEventListener('change', () => overview && renderTasks(overview.tasks));

els.form.addEventListener('submit', async event => {
  event.preventDefault();
  const form = new FormData(els.form);
  const payloadNote = String(form.get('payloadNote') || '').trim();
  try {
    await api('/api/tasks', {
      method: 'POST',
      body: JSON.stringify({
        title: form.get('title'),
        priority: form.get('priority'),
        durationMs: Number(form.get('durationMs')),
        payload: payloadNote ? { note: payloadNote } : {},
        failFirst: form.get('failFirst') === 'on'
      })
    });
    closeModal();
    toast('Task added to the queue.');
    refresh();
  } catch (error) { toast(error.message); }
});

$('#demo-btn').addEventListener('click', async () => {
  try {
    const result = await api('/api/demo', { method: 'POST', body: '{}' });
    toast(`${result.tasks.length} demo tasks added.`);
    refresh();
  } catch (error) { toast(error.message); }
});

els.pauseBtn.addEventListener('click', async () => {
  const paused = els.pauseBtn.dataset.paused === 'true';
  try {
    await api(paused ? '/api/queue/resume' : '/api/queue/pause', { method: 'POST', body: '{}' });
    toast(paused ? 'Queue resumed.' : 'Queue paused. Running jobs will finish.');
    refresh();
  } catch (error) { toast(error.message); }
});

els.deadList.addEventListener('click', async event => {
  const button = event.target.closest('[data-retry]');
  if (!button) return;
  try {
    await api(`/api/dead-letter/${encodeURIComponent(button.dataset.retry)}/retry`, { method: 'POST', body: '{}' });
    toast('Dead-letter task requeued.');
    refresh();
  } catch (error) { toast(error.message); }
});

refresh();
setInterval(refresh, 1000);
