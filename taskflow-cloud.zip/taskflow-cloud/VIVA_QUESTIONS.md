# Viva Questions and Answers

### 1. What is TaskFlow Cloud?
It is a web application that schedules tasks by priority and processes them asynchronously using a background worker pool.

### 2. Why is a task queue required?
A queue separates task submission from execution, improves responsiveness, and gives the system a place to manage ordering, retries, and failures.

### 3. What is priority-based scheduling?
It selects higher-priority eligible tasks before lower-priority tasks. This project uses critical, high, normal, and low priorities.

### 4. How are equal-priority tasks ordered?
The scheduler uses FIFO order, based on the task's creation sequence.

### 5. What is a background worker?
A worker is an execution loop that claims a task, processes it without blocking the HTTP request, and reports success or failure.

### 6. Does this project use multiple operating-system processes?
No. The worker pool consists of asynchronous worker loops within one Node.js process. It demonstrates concurrency, not multi-process parallelism.

### 7. What is the difference between concurrency and parallelism?
Concurrency means multiple tasks can make progress during overlapping time periods. Parallelism means tasks literally execute at the same instant on separate execution resources.

### 8. What are the task statuses?
Queued, running, completed, and failed.

### 9. What is an automatic retry?
It is another attempt to process a task after a failed attempt, provided the configured attempt limit has not been reached.

### 10. What is exponential backoff?
It increases the wait between retries exponentially. Here the delay is the base delay multiplied by two to the power of the previous failed-attempt index.

### 11. Why should retries have a limit?
A limit prevents permanently failing work from consuming resources indefinitely.

### 12. What is a dead-letter queue?
It stores tasks that exhausted their allowed attempts so they can be inspected and deliberately retried or discarded.

### 13. What is the purpose of failure logs?
They retain diagnostic details for each failed attempt, including the task, worker, attempt number, timestamp, and error message.

### 14. What happens when the queue is paused?
Workers stop claiming new tasks. Tasks already running are allowed to finish.

### 15. What does the Node.js `http` module do here?
It creates the web server and handles HTTP requests and responses without an external framework.

### 16. Why use `crypto.randomUUID()`?
It generates unique identifiers for tasks, events, and failure records.

### 17. What does the frontend use to communicate with the server?
The browser's Fetch API sends and receives JSON over REST-style HTTP endpoints.

### 18. Is task data persistent?
No. Data is stored in memory and resets when the server restarts. A production implementation should use durable storage.

### 19. How can a retry be demonstrated?
Create a task and enable “Simulate one failure.” The first attempt fails and is logged; a later attempt succeeds.

### 20. How can the DLQ be demonstrated?
Use a task payload with `forceFailure`, for example through the API: `{"title":"Always fails","priority":"high","payload":{"forceFailure":"test error"}}`. It will eventually exhaust attempts and enter the DLQ.

### 21. How is the application tested?
It uses Node.js's built-in `node:test` and `node:assert/strict` modules. Run `npm test`.

### 22. What is FIFO?
First In, First Out: the earliest-created eligible task in a priority group is selected first.

### 23. What are the main limitations?
In-memory storage, simulated job execution, no authentication, and no cross-process coordination.

### 24. What improvements would you make for production?
Use a durable database or queue, add authentication and authorization, implement worker leases and crash recovery, add metrics and alerting, and secure/rate-limit the API.

### 25. Why is the DLQ useful?
It separates repeatedly failing tasks from normal queue flow and gives an operator a way to investigate errors without losing task context.
