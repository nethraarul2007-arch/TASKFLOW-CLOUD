# TaskFlow Cloud: Priority-Based Job Scheduling and Worker Management

TaskFlow Cloud is a runnable mini job-processing platform built with **HTML, CSS, browser JavaScript, and Node.js built-in modules only**. It demonstrates priority queues, concurrent background workers, task state transitions, automatic retries with exponential backoff, failure logs, and a dead-letter queue.

## Features

- **Priority-based scheduling:** `critical > high > normal > low`; FIFO ordering is preserved for tasks with equal priority.
- **Background worker pool:** configurable workers claim and process jobs concurrently.
- **Task status tracking:** queued, running, completed, and failed states.
- **Automatic retries:** configurable max attempts and exponential backoff.
- **Failure logs:** each failed attempt is recorded with task, worker, attempt number, message, and timestamp.
- **Dead-letter queue (DLQ):** exhausted tasks are isolated and can be manually requeued from the dashboard.
- **Dashboard:** live polling, summary metrics, task filtering, worker status, logs, DLQ, create-task modal, demo tasks, and pause/resume.
- **No external runtime dependencies:** Node.js built-in `http`, `fs`, `path`, `url`, and `crypto` modules only.
- **Tests:** Node's built-in `node:test` runner.

> **Storage note:** this teaching project keeps tasks and logs in memory. Restarting the server clears the session. For production, use persistent storage, authentication, rate limiting, and durable queue infrastructure.

## Requirements

- Node.js 18 or newer
- VS Code (recommended)
- A browser

## Run in VS Code

1. Extract `taskflow-cloud.zip`.
2. Open the extracted `taskflow-cloud` folder in VS Code.
3. Open **Terminal → New Terminal**.
4. Check Node.js is installed:

   ```bash
   node --version
   npm --version
   ```

5. Start the server:

   ```bash
   npm start
   ```

6. Open **http://localhost:3000** in your browser.
7. Click **Load demo** or **New task** to see real background processing.

No `npm install` is required because there are no third-party dependencies.

### Development mode

```bash
npm run dev
```

This uses Node's built-in watch mode to restart the server when source files change.

### Run tests

```bash
npm test
```

The tests cover input validation, priority ordering, FIFO tie-breaking, retries, DLQ handling, pause/resume behavior, and worker ownership.

## Configuration

Environment variables are optional:

| Variable | Default | Meaning |
|---|---:|---|
| `PORT` | `3000` | HTTP port |
| `WORKER_COUNT` | `3` | Number of background workers (1–8) |
| `MAX_ATTEMPTS` | `3` | Maximum attempts before dead-lettering |
| `RETRY_BASE_MS` | `1200` | Base retry delay; exponential backoff is applied |

Examples:

**Windows PowerShell**
```powershell
$env:PORT=3001; $env:WORKER_COUNT=4; npm start
```

**macOS/Linux**
```bash
PORT=3001 WORKER_COUNT=4 npm start
```

## Project structure

```text
taskflow-cloud/
├── public/
│   ├── index.html       # Dashboard structure and task modal
│   ├── styles.css       # Responsive dashboard styles
│   └── app.js           # UI rendering and API interactions
├── src/
│   ├── server.js        # HTTP server, static assets, REST API
│   ├── queue.js         # Queue, scheduling, statuses, retries, logs, DLQ
│   └── worker-pool.js   # Concurrent background worker loop
├── test/
│   └── queue.test.js    # Built-in Node test suite
├── package.json
├── README.md
├── PROJECT_REPORT.md
├── ARCHITECTURE.md
├── VIVA_QUESTIONS.md
└── .gitignore
```

## API reference

| Method | Endpoint | Purpose |
|---|---|---|
| `GET` | `/api/health` | Server health and Node version |
| `GET` | `/api/overview` | Stats, workers, tasks, logs, and DLQ |
| `GET` | `/api/tasks?status=queued` | List/filter tasks |
| `POST` | `/api/tasks` | Create a task |
| `POST` | `/api/demo` | Add five demonstration tasks |
| `POST` | `/api/queue/pause` | Stop assigning new jobs |
| `POST` | `/api/queue/resume` | Resume assignment |
| `POST` | `/api/dead-letter/:taskId/retry` | Requeue a dead-lettered task |
| `DELETE` | `/api/tasks` | Clear terminal task history and logs |

Example task creation:

```bash
curl -X POST http://localhost:3000/api/tasks \
  -H "Content-Type: application/json" \
  -d '{"title":"Generate report","priority":"high","durationMs":1500,"payload":{"format":"pdf"}}'
```

For a guaranteed retry demonstration, set `"failFirst": true`. To force every attempt to fail and test the DLQ, pass a payload such as `"payload":{"forceFailure":"downstream unavailable"}`.

## How priority scheduling works

1. New tasks are added to the waiting list with `queued` status.
2. An idle worker asks the queue for work.
3. The scheduler sorts eligible jobs by priority descending, then creation sequence ascending.
4. The chosen task moves to `running` and is assigned to that worker.
5. Success moves it to `completed`; a failure is logged.
6. If attempts remain, the task is requeued after exponential backoff: `baseDelay × 2^(attempt - 1)`.
7. If attempts are exhausted, the task moves to `failed` and is added to the DLQ.

Pause prevents new tasks from being assigned; already-running jobs finish normally.

## Troubleshooting

- **Port is already in use:** use `PORT=3001 npm start` (PowerShell syntax is in Configuration).
- **Page loads but API is unavailable:** make sure the terminal still shows `TaskFlow Cloud running...`.
- **Tests fail because a port is busy:** unit tests do not start the web server and do not require a free port.
- **Dashboard looks unstyled offline:** the optional Google Fonts import may not load; the system falls back to local sans-serif fonts.

## License

MIT — suitable for educational use and modification.
