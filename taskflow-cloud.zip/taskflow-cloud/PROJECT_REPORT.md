# Project Report
## TaskFlow Cloud: Priority-Based Job Scheduling and Worker Management

### 1. Abstract

TaskFlow Cloud is a lightweight web-based task scheduling system developed using HTML, CSS, JavaScript, and Node.js built-in modules. It accepts tasks with different priority levels and assigns eligible work to background workers. The application tracks task status, records failure details, retries failed jobs with exponential backoff, and moves tasks that exhaust their retry limit to a dead-letter queue. A responsive dashboard provides live visibility into the queue, worker pool, execution results, and failures.

### 2. Problem statement

Applications often need to execute work outside the immediate request-response cycle. Without a queue and worker-management mechanism, long-running jobs can delay user requests, failures can be difficult to investigate, and urgent tasks may wait behind less important work. This project demonstrates a simple architecture that separates task submission from task execution and makes processing behavior observable.

### 3. Objectives

1. Create and maintain a task queue.
2. Schedule jobs according to priority.
3. Execute tasks concurrently using background workers.
4. Track queued, running, completed, and failed states.
5. Retry failed tasks automatically with increasing delay.
6. Record each failure for troubleshooting.
7. Isolate exhausted tasks in a dead-letter queue.
8. Provide a browser dashboard for monitoring and control.

### 4. Technologies used

- **HTML5:** dashboard structure and forms.
- **CSS3:** responsive layout, metrics cards, status indicators, and modal styling.
- **JavaScript:** browser interactions and REST API communication.
- **Node.js:** server runtime and asynchronous worker execution.
- **Built-in Node modules:** `http`, `fs`, `path`, `url`, `crypto`, and `node:test`.

No third-party runtime packages are required.

### 5. System design

The browser sends JSON requests to the Node.js HTTP server. The server validates input and delegates task creation to the queue module. Worker loops claim tasks based on priority and execute a simulated handler. The queue updates status and records results. Failed attempts are logged and scheduled for retry when attempts remain. Once the attempt limit is reached, the task is marked failed and copied into the dead-letter queue. The dashboard periodically requests an overview to update the displayed metrics and lists.

### 6. Functional modules

**Task submission:** accepts a title, priority, duration, optional payload, and optional failure-demo flag.

**Priority scheduler:** ranks critical, high, normal, and low tasks. FIFO ordering is used among tasks with equal priority.

**Worker management:** maintains a configurable pool of workers and exposes each worker's idle/busy state and assigned task.

**Status tracking:** tasks move through queued, running, completed, and failed states.

**Retry manager:** failures are retried up to the configured attempt limit. The delay doubles after each failed attempt.

**Failure logging:** stores task identity, worker, attempt number, error message, and timestamp.

**Dead-letter queue:** retains tasks that fail on every permitted attempt. An operator can manually requeue a task from the dashboard.

**Dashboard:** displays summary counters, task filtering, worker activity, recent failures, DLQ entries, and queue pause/resume controls.

### 7. Scheduling and retry algorithm

1. Select queued tasks whose retry delay has elapsed.
2. Sort by priority weight in descending order.
3. For equal priorities, sort by creation sequence in ascending order.
4. Assign the first eligible task to an idle worker.
5. Mark it running and increment its attempt counter.
6. If successful, mark completed and store the result.
7. If unsuccessful, write a failure log.
8. If attempts remain, schedule retry using `base delay × 2^(attempt - 1)`.
9. Otherwise, mark failed and place the task in the DLQ.

### 8. Testing

The built-in Node test suite checks:
- Required title, supported priority, and duration validation.
- Critical/high/normal/low scheduling and FIFO tie-breaking.
- Automatic retry followed by dead-lettering.
- Manual requeue of dead-lettered tasks.
- Pause behavior.
- Worker ownership checks when completing a task.

Run tests with `npm test`. The expected outcome is that all test cases pass.

### 9. Results

The implementation provides an interactive dashboard backed by a live Node.js server and in-process worker pool. Users can create jobs, load sample tasks, observe concurrent processing, pause or resume dispatch, filter tasks, inspect failed attempts, and requeue dead-lettered jobs. The failure-demo flag provides a predictable way to demonstrate a retry.

### 10. Limitations

Queue state is stored in memory and is lost when the process restarts. The worker handler simulates processing rather than integrating with external services. The system is intended for academic demonstration and is not a replacement for a durable distributed queue.

### 11. Future enhancements

- Store task and event records in a database.
- Add user authentication and role-based access.
- Add real job handlers and file processing.
- Implement worker heartbeats and recovery after worker crashes.
- Add server-sent events or WebSockets instead of one-second polling.
- Add queue metrics, charts, export, and configurable retry policies.
- Support multiple server instances using a shared durable queue.

### 12. Conclusion

TaskFlow Cloud demonstrates the fundamental concepts of priority scheduling and background processing in a compact, dependency-free project. The design separates API handling, scheduling, and worker execution while providing retry behavior, failure observability, and a dead-letter workflow. It is suitable for demonstrating queue management concepts in a project presentation or viva.
