'use strict';

const test = require('node:test');
const assert = require('node:assert/strict');
const { TaskQueue } = require('../src/queue');

function setup() {
  const queue = new TaskQueue({ maxAttempts: 2, retryBaseMs: 1, historyLimit: 50 });
  queue.registerWorker({ id: 'worker-1', name: 'Worker 1' });
  return queue;
}

test('validates task input', () => {
  const queue = setup();
  assert.throws(() => queue.addTask({ title: '' }), /title is required/i);
  assert.throws(() => queue.addTask({ title: 'Bad priority', priority: 'urgent' }), /Priority/);
  assert.throws(() => queue.addTask({ title: 'Bad duration', durationMs: 10 }), /Duration/);
});

test('schedules highest priority first and preserves FIFO within a priority', () => {
  const queue = setup();
  const low = queue.addTask({ title: 'Low', priority: 'low' });
  const high1 = queue.addTask({ title: 'High 1', priority: 'high' });
  const high2 = queue.addTask({ title: 'High 2', priority: 'high' });
  const critical = queue.addTask({ title: 'Critical', priority: 'critical' });
  assert.equal(queue.claimNext('worker-1').id, critical.id);
  queue.completeTask(critical.id, 'worker-1', {});
  assert.equal(queue.claimNext('worker-1').id, high1.id);
  queue.completeTask(high1.id, 'worker-1', {});
  assert.equal(queue.claimNext('worker-1').id, high2.id);
  queue.completeTask(high2.id, 'worker-1', {});
  assert.equal(queue.claimNext('worker-1').id, low.id);
});

test('failed jobs retry then enter dead-letter queue after max attempts', async () => {
  const queue = setup();
  const task = queue.addTask({ title: 'Flaky job' });
  let claimed = queue.claimNext('worker-1');
  assert.equal(claimed.id, task.id);
  assert.equal(queue.failTask(task.id, 'worker-1', new Error('first failure')), true);
  await new Promise(resolve => setTimeout(resolve, 3));
  claimed = queue.claimNext('worker-1');
  assert.equal(claimed.attempts, 2);
  queue.failTask(task.id, 'worker-1', new Error('second failure'));
  assert.equal(queue.getStats().failed, 1);
  assert.equal(queue.deadLetterQueue[0].taskId, task.id);
  assert.equal(queue.failureLogs.length, 2);
});

test('dead-letter jobs can be manually requeued', async () => {
  const queue = setup();
  const task = queue.addTask({ title: 'Manual retry' });
  queue.claimNext('worker-1');
  queue.failTask(task.id, 'worker-1', 'fail one');
  await new Promise(resolve => setTimeout(resolve, 3));
  queue.claimNext('worker-1');
  queue.failTask(task.id, 'worker-1', 'fail two');
  assert.equal(queue.retryDeadLetter(task.id), true);
  assert.equal(queue.deadLetterQueue.length, 0);
  assert.equal(queue.tasks.get(task.id).attempts, 0);
  assert.equal(queue.tasks.get(task.id).status, 'queued');
});

test('paused queue does not assign jobs', () => {
  const queue = setup();
  queue.addTask({ title: 'Wait' });
  queue.paused = true;
  assert.equal(queue.claimNext('worker-1'), null);
  queue.paused = false;
  assert.ok(queue.claimNext('worker-1'));
});

test('only assigned worker can complete a task', () => {
  const queue = setup();
  queue.registerWorker({ id: 'worker-2', name: 'Worker 2' });
  const task = queue.addTask({ title: 'Ownership' });
  queue.claimNext('worker-1');
  assert.equal(queue.completeTask(task.id, 'worker-2', {}), false);
  assert.equal(queue.completeTask(task.id, 'worker-1', { ok: true }), true);
  assert.equal(queue.tasks.get(task.id).status, 'completed');
});
